package homework3;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.aspectj.lang.JoinPoint;

public class BookService {
	private final BookDao bookDao;

	public BookService(BookDao bookDao) {
		this.bookDao = bookDao;
	}

	public void addBook(Book book) {
		bookDao.addBook(book);
	}

	public void updateBook(Book book) {
		bookDao.updateBook(book);
	}

	public void deleteBook(int id) {
		bookDao.deleteBook(id);
	}

	public List<Book> getAllBooks() {
		return bookDao.getAllBooks();
	}

	public Book getBookById(int modifyId) {
		return null;
	}

	public void log() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd (EEE) hh:mm:ss a zzz");
		dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Seoul"));
		Date now = new Date();
		dateFormat.format(now);
		System.out.println(dateFormat.toString());
	}
}
