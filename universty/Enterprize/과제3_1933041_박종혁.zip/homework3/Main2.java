package homework3;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class Main2 {
	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in); Connection connection = DatabaseUtil.getConnection()) {

			BookDao bookDao = new BookDao(connection);
			BookService bookService = new BookService(bookDao);

			while (true) {
				System.out.println("원하는 메뉴 선택 : ");
				System.out.println("1. 책 추가");
				System.out.println("2. 책 수정");
				System.out.println("3. 책 삭제");
				System.out.println("4. 종료");

				int option = scanner.nextInt();
				scanner.nextLine(); // Consume the newline character

				switch (option) {
				case 1:
					System.out.println("책 이름을 적으시오 : ");
					String bookName = scanner.nextLine();
					Book newBook = new Book();
					newBook.setName(bookName);
					bookService.addBook(newBook);
					System.out.println("성공적으로 저장");
					break;

				case 2:
					System.out.println("수정할 책 id 를 적으시오");
					int modifyId = scanner.nextInt();
					scanner.nextLine(); // Consume the newline character
					Book existingBook = bookService.getBookById(modifyId);

					if (existingBook != null) {
						System.out.println("새로운 책 이름을 적으시오");
						String modifiedName = scanner.nextLine();
						existingBook.setName(modifiedName);
						bookService.updateBook(existingBook);
						System.out.println("성공적으로 수정");
					} else {
						System.out.println("일치하는 id를 못 찾음");
					}
					break;

				case 3:
					System.out.println("삭제할 책 id를 적으시오");
					int deleteId = scanner.nextInt();
					scanner.nextLine(); 
					bookService.deleteBook(deleteId);
					System.out.println("성공적으로 삭제");
					break;

				case 4:
					System.out.println("종료합니다.");
					return;

				default:
					System.out.println("선택이 잘못되었습니다");
				}
				
				bookService.log();
				System.out.println("저장된 책 리스트 : ");
				List<Book> books = bookService.getAllBooks();
				for (Book book : books) {
					System.out.println(book.getId() + " - " + book.getName());
				}
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
