package homework3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDao {
	private Connection connection;

	public BookDao(Connection connection) {
		this.connection = connection;
	}

	public BookDao() {
		// TODO Auto-generated constructor stub
	}

	public void addBook(Book book) {
		String query = "INSERT INTO books (name) VALUES (?)";

		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setString(1, book.getName());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateBook(Book book) {
		String query = "UPDATE books SET name = ? WHERE id = ?";

		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setString(1, book.getName());
			statement.setInt(2, book.getId());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteBook(int id) {
		String query = "DELETE FROM books WHERE id = ?";

		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, id);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Book> getAllBooks() {
		List<Book> books = new ArrayList<>();
		String query = "SELECT * FROM books";

		try (Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery(query)) {

			while (resultSet.next()) {
				Book book = new Book();
				book.setId(resultSet.getInt("id"));
				book.setName(resultSet.getString("name"));
				books.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return books;
	}
}
