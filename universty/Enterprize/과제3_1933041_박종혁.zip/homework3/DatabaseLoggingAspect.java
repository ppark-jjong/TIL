package homework3;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DatabaseLoggingAspect {
    private final BookService bookService;

    @Autowired
    public DatabaseLoggingAspect(BookService bookService) {
        this.bookService = bookService;
    }
    


	@AfterReturning(pointcut = "execution(* homework3.BookService.*())", returning = "result")
    public void logDBContent(JoinPoint joinPoint, Object result) {
        if (result instanceof List) {
            System.out.println("DB 저장 정보:");

            List<Book> books = (List<Book>) result;
            for (Book book : books) {
                System.out.println(book.getId() + " - " + book.getName());
            }

            System.out.println();
        }
    }
}
