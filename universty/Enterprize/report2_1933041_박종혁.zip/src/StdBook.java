package homework;

import java.util.Scanner;

public class StdBook {
	private String name;
	Scanner sc = new Scanner(System.in);

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
