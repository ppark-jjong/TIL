package Homework;


public interface IQ1 {
		public String input();
	    public int[] returnpoint(String formula);
	    public int Value(String s);
}
